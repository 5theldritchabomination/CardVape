#!/usr/bin/env python3
import json
import os
from datetime import datetime
import threading
import time
import paho.mqtt.client as paho

# --- CONFIG ---
JSON_FILE = "cards.json"
BACKUP_DIR = "backups"
LOG_FILE = "rfid.log"
MAX_BACKUPS = 10
BACKUP_INTERVAL = 60  # secondes

# ---------------- MQTT ----------------
MQTT_HOST = "192.168.0.150"  # IP du broker
MQTT_PORT = 1883
MQTT_TOPIC = "uid/topic"
MQTT_USER = "admin"
MQTT_PASS = "memel"

# ---------------- LOG ----------------
def log(message):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {message}"
    print(line)
    os.makedirs(os.path.dirname(LOG_FILE) or ".", exist_ok=True)
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(line + "\n")

# ---------------- JSON ----------------
def ensure_json_file(path):
    if not os.path.exists(path):
        with open(path, "w", encoding="utf-8") as f:
            json.dump({}, f, indent=2, ensure_ascii=False)
        log(f"Created empty JSON file: {path}")

def load_db(path):
    ensure_json_file(path)
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        log("JSON file corrupted, resetting.")
        return {}

def save_db(path, db):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(db, f, indent=2, ensure_ascii=False)
    os.replace(tmp, path)

def now_iso():
    return datetime.now().isoformat(timespec="seconds")

def process_uid(db, uid_hex):
    uid_hex = uid_hex.strip().upper()
    t = now_iso()
    entry = db.get(uid_hex)
    if entry is None:
        db[uid_hex] = {"first_seen": t, "last_seen": t, "count": 1}
        log(f"NEW card {uid_hex} at {t}")
    else:
        entry["last_seen"] = t
        entry["count"] = entry.get("count", 0) + 1
        log(f"Updated {uid_hex} -> last_seen={t}, count={entry['count']}")
    return db

# ---------------- BACKUP ----------------
def make_backup(db):
    os.makedirs(BACKUP_DIR, exist_ok=True)
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    backup_file = os.path.join(BACKUP_DIR, f"cards_{timestamp}.json")

    # Sauvegarde uniquement les cartes
    cards_only = {k: v for k, v in db.items() if not k.startswith("backup_")}
    with open(backup_file, "w", encoding="utf-8") as f:
        json.dump(cards_only, f, indent=2, ensure_ascii=False)
    log(f"Backup saved: {backup_file}")

    # Garder seulement les N derniers backups
    backups = sorted(os.listdir(BACKUP_DIR))
    while len(backups) > MAX_BACKUPS:
        old = backups.pop(0)
        os.remove(os.path.join(BACKUP_DIR, old))
        log(f"Removed old backup: {old}")

def periodic_backup(client_data):
    while True:
        time.sleep(BACKUP_INTERVAL)
        db = client_data["db"]
        save_db(JSON_FILE, db)
        make_backup(db)
        log("Periodic backup completed.")

# ---------------- MQTT ----------------
def on_connect(client, userdata, flags, rc):
    if rc == 0:
        log(f"Connected successfully to MQTT broker {MQTT_HOST}:{MQTT_PORT}")
        client.subscribe(MQTT_TOPIC)
    else:
        log(f"Failed to connect, return code {rc}")

def on_message(client, userdata, msg):
    payload = msg.payload.decode("utf-8", errors="ignore").strip()
    log(f"Received UID: {payload} (topic={msg.topic})")
    db = userdata["db"]
    db = process_uid(db, payload)
    save_db(JSON_FILE, db)

def main():
    ensure_json_file(JSON_FILE)
    db = load_db(JSON_FILE)
    log(f"Loaded {len(db)} known cards from {JSON_FILE}")

    client_data = {"db": db}
    client = paho.Client(userdata=client_data)
    client.username_pw_set(MQTT_USER, MQTT_PASS)  # <-- Authentification
    client.on_connect = on_connect
    client.on_message = on_message

    client.connect(MQTT_HOST, MQTT_PORT, 60)
    log("Listening for UIDs on MQTT...")

    # Thread pour backup périodique
    backup_thread = threading.Thread(target=periodic_backup, args=(client_data,), daemon=True)
    backup_thread.start()

    try:
        client.loop_forever()
    except KeyboardInterrupt:
        log("Stopped by user.")
        save_db(JSON_FILE, client_data["db"])
        make_backup(client_data["db"])
        log("DB saved. Bye.")

if __name__ == "__main__":
    main()
